package Practica01Lucas.Practica01Lucas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica01LucasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Practica01LucasApplication.class, args);
	}

}
