package Practica01Lucas.Practica01Lucas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica01LucasApplicationTests {

	@Test
	void contextLoads() {
	}

}
